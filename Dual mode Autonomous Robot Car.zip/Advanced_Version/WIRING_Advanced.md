# Dual-Mode Delivery Robot – ADVANCED challenge (Figure 2 map) – Arduino Mega 2560

| File | What it is |
|---|---|
| `DeliveryRobot_Advanced/DeliveryRobot_Advanced.ino` | Main program for the **Mega 2560** (fully automatic mission) |
| `ESP01_App_Advanced/ESP01_App_Advanced.ino` | WiFi phone app for the **ESP-01**: live status, AUTO/MANUAL switch, driving, arm, colour override |
| `SD_Card_Voice/01/001.wav … 015.wav` | Voice files: copy the **`01` folder** to the root of the DFPlayer microSD card (FAT32) |
| `DeliveryRobot_Advanced.fzz` / `DeliveryRobot_Advanced_breadboard.png` | Fritzing circuit diagram and its picture |

Older folders (`Mega_Version`, …) are not changed.

**Libraries**: open the Library Manager, install **Adafruit SSD1306**, and accept "install all" so it also installs GFX and BusIO. Board: *Arduino Mega or Mega 2560*.
**ESP-01**: install the ESP8266 board package, choose *Generic ESP8266 Module*, and upload with a USB ESP-01 programmer.
The Mega and the ESP talk at **115200 baud**, so both sketches must be uploaded. They are a matched pair.

---

## 1. Power

```
2x18650 7.4 V ─┬─► L298N 12V (5V-EN jumper ON, ENA/ENB jumpers OFF)
               ├─► Mega VIN
               └─► LM2596 (set 5.0 V first!) ─► Breadboard 1 servo rail ─► 2 servos
                                             └─► Breadboard 2 rail ─► DFPlayer, ESP-01 adapter, OLED, KY-032, HW-496, TCS3200
Mega 5V ─► Breadboard 1 logic rail ─► IR LEFT, HW-511 CENTRE, IR RIGHT
ALL GND connected together
```

## 2. Mega 2560 pin map

| Mega pin | Connects to |
|---|---|
| D2 | KY-032 OUT (LOW = obstacle) |
| D3 | **HW-496 OUT** (sound sensor, interrupt pin) |
| D6 / D7 / D8 / D9 / D10 / D11 | L298N ENB / IN4 / IN3 / IN2 / IN1 / ENA |
| D14 (TX3) | 1 kΩ resistor → DFPlayer RX |
| D15 (RX3) | DFPlayer TX |
| D16 | DFPlayer BUSY |
| D18 (TX1) / D19 (RX1) | ESP-01 adapter RX / TX |
| D20 (SDA) / D21 (SCL) | OLED SDA / SCL |
| D23 / D25 / D27 | TCS3200 OUT / S2 / S3 |
| **D31** | IR sensor **LEFT** OUT |
| **D33** | **HW-511 tracking sensor CENTRE** OUT |
| **D35** | IR sensor **RIGHT** OUT |
| D45 | Servo 1 **ARM** (raise / lower) |
| D47 | Servo 2 **GRIPPER** (grab / release) |
| VIN | Battery + 7.4 V |

## 3. Module wiring

| Module | Pins |
|---|---|
| IR LEFT / IR RIGHT | VCC → Mega 5V rail, GND → GND, OUT → D31 / D35 |
| HW-511 (centre) | VCC → Mega 5V rail, GND → GND, OUT → D33 *(follow the labels on your board)* |
| TCS3200 | VCC → 5 V (breadboard 2), GND → GND, S0 → VCC, S1 → GND, OUT → D23, S2 → D25, S3 → D27, LED → not connected |
| HW-496 | VCC → 5 V, GND → GND, OUT → D3. **Turn the potentiometer to LOW sensitivity**: the LED should only flash on a loud clap |
| KY-032 | + → 5 V, GND → GND, OUT → D2, EN jumper on. Set the range to about **5 cm** (it stops the robot in front of the ball) |
| DFPlayer Mini | VCC → 5 V, GND → GND, RX ← 1 kΩ ← D14, TX → D15, BUSY → D16, SPK1 / SPK2 → speaker (8 Ω 1.5 W) |
| OLED | VCC → 5 V, GND → GND, SDA → D20, SCL → D21 (0x3C; if the screen stays black, try 0x3D) |
| ESP-01 adapter | VCC → 5 V, GND → GND, RX → D18, TX → D19 |
| Servos | red → servo 5 V rail, brown → GND, orange → D45 (arm) / D47 (gripper) |

### Sensor placement (important)

```
        front of robot
   [IR L]   [HW-511]   [IR R]        <- in one row, 1-2 cm above the floor
      |<-- 15 mm -->|<-- 15 mm -->|
            ======= black line (19 mm) =======
                                 [TCS3200] <- right side, 6-12 cm right of the centre line, facing down
```

* The HW-511 sits **on** the line, and the two IR sensors sit **just outside** the line edges (about 15 mm from the centre).
* Line following: if the centre sees black, the robot goes straight. If the centre is lost, the IR sensor that still sees black tells which way to steer.
* **Junction**: the centre and one side see black together. The robot **slows down** at every junction and counts the junctions to find the ball and station branches.
* **Corner**: a side sensor saw black and then the line ended. The robot turns towards that side.
* **T** (all 3 black): the end bar of a branch, the main line when coming back out of a branch, or the edge of a base.
* **Dash line**: the centre sensor sees short white gaps (1 cm). After 2 gaps the robot slows down and says "Slow down".

## 4. Mission (fully automatic)

1. The robot waits in **base 1**. **Double clap** (or press AUTO in the app) → "Auto mode".
2. Top line to the right. At the dash line → "Slow down". The TCS3200 reads the 3 colour papers on the right:
   * colour 1 → ball number, e.g. "Red. Ball number one"
   * colour 2 → station number, e.g. "Blue. Station number two"
   * colour 3 → base, e.g. "Red. Base one" (colour 3 is only red or blue)
3. Corner → down the right side, passing the stations → corner → bottom line → turn into **ball N** → stop in front of the ball (KY-032 or end bar) → **grab** (arm down, gripper closes, arm up).
4. U-turn → back to the bottom line → turn right → corner → up the right side → turn into **station S** → over the ring → **unload**.
5. U-turn → back to the right side → **base 1** (up, then back along the top line) or **base 2** (down, then along the bottom line) → into the base → "Mission complete".

Red = 1, Blue = 2, Green = 3 (ball / station). Red = base 1, Blue = base 2.

## 5. Voice files (SD card, folder `01`)

| File | Says |
|---|---|
| 001 | Auto mode |
| 002 | Slow down |
| 003 / 004 / 005 | Red. Ball number one / Blue. Ball number two / Green. Ball number three |
| 006 / 007 / 008 | Red. Station number one / Blue. Station number two / Green. Station number three |
| 009 / 010 | Red. Base one / Blue. Base two |
| 011 / 012 | Switch to manual mode / Switch to auto mode |
| 013 / 014 / 015 | Colour detect fail / Obstacle detected / Mission complete |

To use your own recordings, keep the same file numbers (MP3 or WAV).

## 6. Phone app (WiFi)

Connect your phone to the WiFi **AirostRobot** (password `robot1234`), then open **http://192.168.4.1**.

* **Status** (updates live): mode, current step, colour 1/2/3 with their ball / station / base, junction counter, L-C-R line sensors, obstacle, speed / volume, and the latest message. It also shows *online / offline*.
* **Mode**: AUTO / MANUAL / STOP. AUTO at base 1 starts the mission, the same as a double clap. Pressing AUTO later continues from the current step, so put the robot back on the line first.
* **Drive** (hold the button), **arm up / down / home**, **gripper open / close**, **GRAB / UNLOAD**.
* **Colour override**: if a colour paper was not read, the robot stops after the top line ("Colour detect fail"). Set colours 1/2/3 by hand, then press AUTO.
* Speed ±, volume ±, Restart (back to the start of the mission at base 1).

## 7. Calibration / tuning (Serial Monitor, 115200)

| Send | Shows / does |
|---|---|
| `I` or `K` | Line sensors L C R (1 = black) and the TCS3200 R G B values with the colour it sees |
| `O` | KY-032 state and the HW-496 edge count per 20 ms (for clap tuning) |
| `?` | Status line |
| `C1R`, `C2B`, `C3R` … | Set colour 1/2/3 by hand |
| `A M X Z F B L R S u d o c h G P + - V v` | Same as the app buttons |

1. **Line sensors**: send `I` over black and white. If black shows 0, change `IR_BLACK` / `TRACK_BLACK` to `LOW`.
2. **Colours**: hold the TCS3200 over red, green and blue paper and over the bare floor, send `K` for each, and copy the R G B numbers into `colourRefs[]`.
3. **Motors**: if a wheel turns the wrong way, set `LEFT_MOTOR_REVERSED` / `RIGHT_MOTOR_REVERSED`.
4. **Turns**: `TURN_ADVANCE_MS` (how far it drives past a junction before pivoting), `CORNER_ADVANCE_MS`, `T_ADVANCE_MS`.
5. **Junctions**: `JUNC_CONFIRM_MS`. Raise it if wobbling is counted as a junction; lower it if junctions are missed.
6. **Ball / station**: `GRAB_ADJUST_MS`, `STATION_FORWARD_MS`, servo angles `ARM_UP/DOWN`, `GRIP_OPEN/CLOSE`.
7. **Double clap**: first lower the HW-496 sensitivity with the potentiometer. Then tune `CLAP_MIN_EDGES` (higher = less sensitive) and the time between the 2 claps (`CLAP_GAP_MIN_MS` / `CLAP_GAP_MAX_MS`).
8. **Obstacle**: the robot stops and says "Obstacle detected", then continues after the path has been clear for 0.6 s. If it is still blocked after 15 s, it switches to manual. The KY-032 is ignored inside the ball and station branches. If it sees the ball the robot is carrying, set `OBSTACLE_IGNORE_WHILE_CARRYING = true`.
